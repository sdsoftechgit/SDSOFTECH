var app = angular.module('ngApp', [ "ngRoute", "ngTouch", "mobile-angular-ui" ]);

app.config(function($routeProvider, $locationProvider) {
	$routeProvider.when('/', {
		templateUrl : "../PayRollUI/views/login.html"
	});
	$routeProvider.when('/employee', {
		templateUrl : '../PayRollUI/views/employee.html'
	});

});


app.controller('MainController', [ '$scope', '$location', '$http',

function($scope, $location, $http) {

	$scope.user = {
			username : ""
		};
	
	$scope.logout = function() {
		$scope.user = {
			username : ""
		};
		$location.path('/');
	};

	$scope.signin = function() {
		console.log('Signing In');
		var userId = $scope.user.username;
		
		if (userId!=null && userId!="") {
			$http({
			    method: 'GET',
			    url: 'http://localhost:7070/springjson/employeeinfo.json',
			    headers: { 'Content-Type': 'application/json'}
			    }).then(function(result) {
			           console.log(result);
			           $scope.Details="";
			           $scope.loggedIn = true;
			           $location.path('/employee');
					   $scope.Details = result.data;
						
			       }, function(error) {
			           console.log(error);
			       });
		}
	};
	} ]);

	

